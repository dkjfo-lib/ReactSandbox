export default function Header(){
    return(
        <nav className='header'>
            <h1>Header</h1>
        </nav>
    )
}